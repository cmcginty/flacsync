.. flacsync // (c) 2011, Patrick C. McGinty
   flacsync[@]tuxcoder[dot]com

v0.3.2
==========
:Release Date: 10/10/2011

* Support duplicate tags names in FLAC files (i.e multi-artist)
* Add MP3 encoder support
* Add option to disable cover art resizing
* Add option to copy cover art to destination directories

v0.3.1
==========
:Release Date: 6/11/2011

* Initial GitHub release
